import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      welcome: 'Welcome to Bayl',
      products: 'Products',
      cart: 'Cart',
      checkout: 'Checkout',
    },
  },
  pt: {
    translation: {
      welcome: 'Bem-vindo ao Bayl',
      products: 'Produtos',
      cart: 'Carrinho',
      checkout: 'Finalizar Compra',
    },
  },
  es: {
    translation: {
      welcome: 'Bienvenido a Bayl',
      products: 'Productos',
      cart: 'Carrito',
      checkout: 'Pagar',
    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'en', // idioma padrão
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;