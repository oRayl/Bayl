import React from 'react';

function Cart() {
  return (
    <div>
      <h1>Carrinho</h1>
      <p>Veja os itens no seu carrinho.</p>
    </div>
  );
}

export default Cart;