import React from 'react';

function Checkout() {
  return (
    <div>
      <h1>Finalizar Compra</h1>
      <p>Complete seu pedido.</p>
    </div>
  );
}

export default Checkout;