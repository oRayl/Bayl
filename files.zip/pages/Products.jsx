import React from 'react';

function Products() {
  return (
    <div>
      <h1>Produtos</h1>
      <p>Confira nossos produtos incríveis.</p>
    </div>
  );
}

export default Products;