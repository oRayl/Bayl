import React from 'react';

function Home() {
  return (
    <div>
      <h1>Bem-vindo ao Bayl</h1>
      <p>Plataforma de e-commerce inovadora com suporte para múltiplos idiomas e moedas.</p>
    </div>
  );
}

export default Home;